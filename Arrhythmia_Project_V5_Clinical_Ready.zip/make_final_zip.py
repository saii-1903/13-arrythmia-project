import os
import zipfile
from pathlib import Path

def make_final_v5_zip():
    # Define project name
    zip_name = "Arrhythmia_Project_V5_Clinical_Ready.zip"
    
    # Folders to EXCLUDE
    exclude_dirs = {
        '.git', 
        '__pycache__', 
        'venv', 
        '.venv', 
        'env', 
        'node_modules', 
        '.pytest_cache', 
        '.ipynb_checkpoints',
        'retraining_data' # Exclude massive data folders if they exist
    }
    
    # Extensions to EXCLUDE
    exclude_ext = {'.pyc', '.pyo', '.pyd', '.zip', '.pth'} # We exclude .pth to keep zip light, but keep code

    root_dir = Path.cwd()
    print(f"[>] Packaging project: {root_dir.name}")

    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Filtering directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                if any(file.endswith(ext) for ext in exclude_ext):
                    continue
                
                file_path = Path(root) / file
                arcname = file_path.relative_to(root_dir)
                
                # Don't include the zip file itself
                if file == zip_name:
                    continue
                    
                zipf.write(file_path, arcname)
                
    print(f"[✅] SUCCESS: Created {zip_name}")

if __name__ == "__main__":
    make_final_v5_zip()
